# 智能门户模拟原型

方向1 明亮企业办公。25类桌面页面、4类移动关键页面。所有业务数据和提交都是模拟，不连接生产API或真实身份。来源及确认边界见完整审核包。

Windows安装本地依赖（仓内执行，不安装到全局）：
```powershell
npm ci --ignore-scripts --no-audit --no-fund
npm run dev -- --host 127.0.0.1 --port 4173 --strictPort
```
访问 http://127.0.0.1:4173/ 。关闭终端服务后预览停止，审核截图仍可离线查看。

定向验证：
```powershell
node --test "tests/model.test.mjs"
node "node_modules/vite/bin/vite.js" build
```
本包没有启用发布。starter保留Sites适配文件，不代表获准外网发布或生产部署。

上传仅校验文件名、类型和大小；人工复核记录留在页面会话内存，刷新清空；财务输入与勾选不付款、不结案；统一待办为设计目标；未建部门为规划模板；概念品牌标记须经核官方资产替换。
