export const pages = [
 ['P01','login','员工登录','公共门户'],['P02','home','门户首页','公共门户'],['P03','apps','应用目录','公共门户'],['P04','tasks','我的待办','公共门户'],['P05','review','人工复核','公共门户'],['P06','system','系统与发布','公共门户'],
 ['P07','procurement','采购部','部门入口'],['P08','quality','质量部','部门入口'],['P09','finance','财务部','部门入口'],['P10','sales','销售部','部门入口'],['P11','operations','运营管理','部门入口'],['P12','engineering','工程研发','部门入口'],
 ['P13','qd-upload','QD-B立项预审 · 上传','质量样板'],['P14','qd-report','QD-B预审报告','质量样板'],['P15','qd-evidence','规则与证据','质量样板'],['P16','q2-summary','Q2 8D评审汇总','质量样板'],['P17','q2-review','8D报告复核','质量样板'],
 ['P18','sc8-products','SC8成品保供看板','采购适配'],['P19','sc8-materials','SC8物料覆盖','采购适配'],['P20','sc8-cases','SC8案例处置','采购适配'],['P21','sc8-correction','SC8判例批改','采购适配'],['P22','sc2-weekly','SC2采购周报','采购适配'],
 ['P23','fi2-input','FI2对账输入','财务参考'],['P24','fi2-result','FI2对账结果','财务参考'],['P25','fi3-checklist','FI3付款校验清单','财务参考'],
].map(([id,path,title,group])=>({id,path,title,group}));
export const departments = [
 {path:'procurement',name:'采购部',desc:'保供与采购周报',icon:'shopping',color:'blue',status:'内部试用'},
 {path:'quality',name:'质量部',desc:'立项预审与8D评审',icon:'shield',color:'teal',status:'试点'},
 {path:'finance',name:'财务部',desc:'对账与付款校验',icon:'bank',color:'gold',status:'需求待确认'},
 {path:'sales',name:'销售部',desc:'客户与销售协作',icon:'chart',color:'purple',status:'规划'},
 {path:'operations',name:'运营管理',desc:'运营任务与异常处理',icon:'briefcase',color:'cyan',status:'规划'},
 {path:'engineering',name:'工程研发',desc:'研发场景规划',icon:'chip',color:'indigo',status:'规划'},
];
export const apps = [
 {title:'QD-B立项预审',code:'QD-B',dept:'质量部',path:'qd-upload',desc:'从项目资料中定位风险，形成可复核的预审报告。',status:'试点',icon:'document',color:'blue'},
 {title:'SC8保供看板',code:'SC8',dept:'采购部',path:'sc8-products',desc:'查看成品覆盖、瓶颈物料与处置案例。',status:'内部试用',icon:'cube',color:'teal'},
 {title:'Q2 8D评审',code:'Q2',dept:'质量部',path:'q2-summary',desc:'对照D1–D7查看发现与证据，交由人工复核。',status:'模拟',icon:'clipboard',color:'purple'},
 {title:'SC2采购周报',code:'SC2',dept:'采购部',path:'sc2-weekly',desc:'按期次查看采购快照、重点变化与明细。',status:'现网待复核',icon:'chart',color:'cyan'},
 {title:'FI2对账辅助',code:'FI2',dept:'财务部',path:'fi2-input',desc:'三源对照、定位差异，保留财务结案权。',status:'需求待确认',icon:'bank',color:'gold'},
 {title:'FI3付款校验',code:'FI3',dept:'财务部',path:'fi3-checklist',desc:'查看逐单校验依据，付款由财务人员执行。',status:'需求待确认',icon:'clipboard',color:'gold'},
];
export const tasks = [
 {id:'DEMO-QD-001',title:'项目示例A · 立项预审确认',dept:'质量部',type:'立项预审',level:'待人工确认',date:'2026-10-07 15:20',path:'review'},
 {id:'DEMO-Q2-002',title:'8D报告示例B · 证据补充复核',dept:'质量部',type:'8D评审',level:'需补充资料',date:'2026-10-07 14:40',path:'q2-review'},
 {id:'DEMO-SC-003',title:'物料示例M-02 · 供应承诺核对',dept:'采购部',type:'保供案例',level:'待人工确认',date:'2026-10-07 13:10',path:'sc8-correction'},
 {id:'DEMO-FI-004',title:'供应商甲 · 对账差异确认',dept:'财务部',type:'对账辅助',level:'需求待确认',date:'2026-10-07 11:35',path:'fi2-result'},
];
export const products = [
 {id:'FG-DEMO-01',name:'成品示例A',demand:1200,available:860,coverage:12,status:'风险',material:'M-DEMO-02',owner:'采购专员',color:'red'},
 {id:'FG-DEMO-02',name:'成品示例B（用于验证长中文品名展示与内容换行）',demand:800,available:920,coverage:26,status:'关注',material:'M-DEMO-03',owner:'采购专员',color:'gold'},
 {id:'FG-DEMO-03',name:'成品示例C',demand:500,available:720,coverage:35,status:'覆盖',material:'M-DEMO-01',owner:'采购专员',color:'teal'},
 {id:'FG-DEMO-04',name:'成品示例D',demand:300,available:null,coverage:null,status:'缺资料',material:'待补子件',owner:'待指定',color:'gray'},
 {id:'FG-DEMO-05',name:'成品示例E',demand:650,available:310,coverage:9,status:'风险',material:'M-DEMO-02',owner:'采购专员',color:'red'},
 {id:'FG-DEMO-06',name:'成品示例F',demand:400,available:660,coverage:42,status:'覆盖',material:'M-DEMO-04',owner:'采购专员',color:'teal'},
];
export const modules = ['项目信息','立项依据','项目的目的和意义','项目目标','关键技术与开发能力评估','项目风险分析','项目所需资源采购计划','项目成本及收益分析','项目里程碑计划与阶段预算规划','项目现金流分析','项目团队成员','总结','立项决议'];
export const states = ['正常','加载','空数据','失败','数据陈旧','权限不足','待确认'];
export const pageFor = path => pages.find(p=>p.path===path.split('?')[0]) || pages[1];
export function filterItems(items,q,field,value){const query=q.trim().toLowerCase();return items.filter(x=>(!query||Object.values(x).join(' ').toLowerCase().includes(query))&&(!value||value==='全部'||x[field]===value));}
export function validateReview(decision,reason){if(!decision)return '请选择复核决定';if(reason.trim().length<6)return '请填写至少6个字的人工复核意见';return '';}
export function validateFile(file){if(!file)return '请选择资料文件';if(!/\.xlsx$/i.test(file.name))return '仅支持 XLSX 立项申请书';if(file.size>20*1024*1024)return '单个文件不能超过20 MB';return '';}

export const materialRows=[
{id:'MAT-DEMO-01',name:'关联成品示例C',material:'M-DEMO-01',demand:900,available:1200,coverage:35,status:'覆盖',color:'teal'},
{id:'MAT-DEMO-02',name:'关联成品示例A、E',material:'M-DEMO-02',demand:1600,available:600,coverage:9,status:'风险',color:'red'},
{id:'MAT-DEMO-03',name:'关联成品示例B',material:'M-DEMO-03',demand:750,available:800,coverage:26,status:'关注',color:'gold'},
{id:'MAT-DEMO-04',name:'关联成品示例D、F',material:'M-DEMO-04',demand:600,available:null,coverage:null,status:'缺资料',color:'gray'},
];
